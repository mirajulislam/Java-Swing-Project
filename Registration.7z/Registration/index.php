<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Tutorial-22</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
            <script type="text/javascript" src="js/jquery.min.js"></script>
            <script type="text/javascript" src="js/raj.js"></script>
            <link href="style.css" rel="stylesheet" type="text/css" media="screen">
                <script type="text/javascript" src="script.js"></script>
                </head>
                <body>

                    <div class="signin-form">

                        <div class="container">


                            <form class="form-signin" method="post" id="register-form">

                                <h2 class="form-signin-heading">Sign Up</h2><hr />

                                <div id="error">
                                </div>

                                <div class="form-group">
                                    <b><font size="3" color="00CED1">User-Name</font></b>  <input type="text" class="form-control" placeholder="Username" name="user_name" id="user_name" />
                                </div>

                                <div class="form-group">
                                    <b><font size="3" color="00CED1">Full-Name</font></b><input type="text" class="form-control" placeholder="Full Name" name="full_name" id="full_name" />
                                </div>

                                <div class="form-group">
                                    <b><font size="3" color="00CED1">Date-Of-Birth</font></b><input type="date" class="form-control" placeholder="Date Of Birth" name="birth" id="birth" />
                                </div>

                                <div class="form-group"> <b><font size="3" color="00CED1">Select Gender</font></b>
                                    <select id="Gender" class="form-control" name="gender" placeholder="select gender" id="gender">
                                        <option value=""></option>  
                                        <option value="male">MALE</option>  
                                        <option value="female">FEMALE</option>  
                                    </select></div>

                                <div class="form-group">
                                     <b><font size="3" color="00CED1">E-mail</font></b><input type="email" class="form-control" placeholder="Email address" name="user_email" id="user_email" />
                                    <span id="check-e"></span>
                                </div>

                                <div class="form-group">
                                     <b><font size="3" color="00CED1">Password(must be-eight )</font></b><input type="password" class="form-control" placeholder="Password" name="password" id="password" />
                                </div>



                                <div class="form-group">
                                    <b><font size="3" color="00CED1">Conform-Password</font></b> <input type="password" class="form-control" placeholder="Retype Password" name="cpassword" id="cpassword" />
                                </div>
                                <hr />
                                
                                <div class="form-group">
                                    <b><font size="3" color="00CED1">Upload-Photo</font></b> <input type="file" class="form-control" placeholder="choose image" name="file" id="image" />
                                </div>
                                <hr />

                                <div class="form-group">
                                    <button type="submit" class="btn btn-default" name="btn-save" id="btn-submit">
                                        <span class="glyphicon glyphicon-log-in"></span> &nbsp; Create Account
                                    </button>
                                </div>

                            </form>

                        </div>

                    </div>

                    <!--<script src="js/bootstrap.min.js"></script>-->
                </body>
                </html>
