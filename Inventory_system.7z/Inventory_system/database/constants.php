<?php
session_start();
define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","molla_inventory");

define("DOMAIN","http://localhost/Inventory_system/");

?>

