$('document').ready(function ()
{
    /* validation */
    $("#register-form").validate({
        rules:
                {
                    user_name: {
                        required: true,
                        minlength: 3
                    },
                    full_name: {
                        required: true,
                        minlength: 3
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        maxlength: 15
                    },
                    cpassword: {
                        required: true,
                        equalTo: '#password'
                    },
                    user_email: {
                        required: true,
                        email: true
                    },
                    birth: {
                        required: true,
                        date: true
                    },
                 gender: {
                        required: true
                       
                    },
                       file: {
                        required: true
                       
                    }
                },
        messages:
                {
                    user_name: "Enter a Valid Username",
                    full_name: "Enter a  Full Name",
                    birth: "Enter a  Date Of Birth",
                    gender:"Select Gender",
                    file:"Upload  Photo",
                    password: {
                        required: "Provide a Password",
                        minlength: "Password Needs To Be Minimum of 8 Characters"
                    },
                    user_email: "Enter a Valid Email",
                    cpassword: {
                        required: "Retype Your Password",
                        equalTo: "Password Mismatch! Retype"
                    }
                },
        submitHandler: submitForm
    });
    /* validation */

    /* form submit */
    function submitForm()
    {
        var data = $("#register-form").serialize();

        $.ajax({
            type: 'POST',
            url: 'register.php',
            data: data,
            beforeSend: function ()
            {
                $("#error").fadeOut();
                $("#btn-submit").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...');
            },
            success: function (data)
            {
                if (data == 1) {

                    $("#error").fadeIn(1000, function () {


                        $("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; Sorry email already taken !</div>');

                        $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Create Account');

                    });

                }
                else if (data == "registered")
                {

                    $("#btn-submit").html('Signing Up');
                    setTimeout('$(".form-signin").fadeOut(500, function(){ $(".signin-form").load("successreg.php"); }); ', 5000);

                }
                else {

                    $("#error").fadeIn(1000, function () {

                        $("#error").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-info-sign"></span> &nbsp; ' + data + ' !</div>');

                        $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Create Account');

                    });

                }
            }
        });
        return false;
    }
    /* form submit */

});

