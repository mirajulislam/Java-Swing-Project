<?php
include_once("./database/constants.php");
if (!isset($_SESSION["userid"])) {
    header("location:" . DOMAIN . "/");
}
?>

<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="includes/style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
        <script src="js/main.js">
        </script>
    </head>
    <body>
        <?php
//navber 
        include_once ("./templete/header.php");
        ?>
        <br/>
        <p><br/> </p>

        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card" >
                        <img src="images/user.png" class="card-img-top mx-auto" style="width: 60%;"alt="user_profile">
                        <div class="card-body mx-auto" >
                            <h5 class="card-title">Profile Info</h5>
                            <p class="card-text"><i class="fa fa-user">&nbsp;</i>Miraj Islam</p>
                            <p class="card-text"><i class="fa fa-user">&nbsp;</i>Admin</p>
                            <p class="card-text">Last Login: xxxx-xx-xx</p>
                            <a href="#" class="btn btn-primary"><i class="fa fa-edit">&nbsp;</i>Edit Profile</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="jumbotron" style="width: 100%;height: 100%;">
                        <h1>Welcome Admin</h1>
                        <div class="row">
                            <div class="col-sm-6">
                                <iframe src="http://free.timeanddate.com/clock/i6kavivz/n73/szw160/szh160/hoc009/hbw0/hfc9ff/cf100/hnc0f9/hwc000/fan2/fas16/fac555/fdi60/mqcf0f/mqs4/mql2/mqw4/mqd78/mhcf90/mhs4/mhl3/mhw4/mhd78/mmv0/hhc990/hhs2/hmc990/hms2/hscf09" frameborder="0" width="160" height="160"></iframe>
                            </div>
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">New Orders</h5>
                                        <p class="card-text">Here you can make invoices and create a new orders</p>
                                        <a href="new_order.php" class="btn btn-primary">New orders</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <p></p>
        <p></p>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body" >
                            <h5 class="card-title">Categories</h5>
                            <p class="card-text">Here you can make manage your categories and you can add new parent and sub categories</p>
                            <a href="templete/category.php" class="btn btn-primary" data-toggle="modal" data-target="#form_categories">Add</a>
                            <a href="manage_categories.php" class="btn btn-primary">Manages</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Brand</h5>
                            <p class="card-text">Here you can make manage your brand and you can add new brand</p>
                            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#form_brand">Add</a>
                            <a href="manage_brand.php" class="btn btn-primary">Manages</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body" >
                            <h5 class="card-title">Products</h5>
                            <p class="card-text">Here you can make manage your products and you can  add new products</p>
                            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#form_product">Add</a>
                            <a href="manage_product.php" class="btn btn-primary">Manages</a>
                        </div>
                    </div>             
                </div>
            </div>
        </div>


        <!-- Modal for categories -->
        <?php
        include_once ("./templete/category.php");
        ?>
        <!-- Modal for brand -->
        <?php
        include_once ("./templete/brand.php");
        ?>
        <!-- Modal for product -->
        <?php
        include_once ("./templete/products.php");
        ?>
    </body>
</html>

